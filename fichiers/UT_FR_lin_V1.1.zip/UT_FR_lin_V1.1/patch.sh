#!/bin/bash
clear
printf "Bonjour ! Bienvenue sur l'installeur Linux du patch FR Undertale (patch Vx, installeur V2.1git) !\n"
printf "Vérification de l'existence des fichiers...\n"


#Création des variables de filecheck
scriptloc="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
datafile="/game.unx"
datafile=$scriptloc$datafile
patchfilest="/patchlinuxst.xdelta"
patchfilest=$scriptloc$patchfile
patchfilegog="/patchlinuxgog.xdelta"
patchfilegog=$scriptloc$patchfile
backupfile="/game.unx.backup"
backupfile=$scriptloc$backupfile


#Variables couleurs de texte
white=$(tput setaf 7)
red=$(tput setaf 1)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
normal=$(tput sgr0)


#Demande de version du jeu
function askplatform () {
	clear
	printf "${yellow}Utilisez-vous la version Steam ou GoG du jeu ?\n1)Steam\n2)GoG\n"
	printf "${white}Tapez 1 ou 2 selon la version de votre jeu puis entrée : "
	read version
	if [[ "$version" = "1" ]]; then
		if [[ -e "$patchfilest" ]]; then
			printf "\nVersion Steam sélectionnée.\nPoursuite de l'opération...\n"
		else
			clear
			printf "\n${red}Vous avez sélectionné la version Steam, mais\nle patch xdelta n'est pas présent !\nArrêt.\n${white}"
			exit
		fi
	elif [[ "$version" = "2" ]]; then
		if [[ -e "$patchfilegog" ]]; then
			printf "\nVersion GoG sélectionnée.\nPoursuite de l'opération...\n"
		else
			clear
			printf "\n${red}Vous avez sélectionné la version GoG, mais\nle patch xdelta n'est pas présent !\nArrêt.\n${white}"
			exit 0
		fi
	else
		printf "Entrée invalide. Appuyez sur entrée pour recommencer.\n"
		askplatform
	fi
	read
	if [ "$xdelta" = "0" ]; then
		do_it_install
	elif [ "$xdelta" = "1" ]; then
		do_it_noinstall
	else
		clear
		printf "${red}Erreur interne : La variable xdelta est erronée !\nCette erreur est causée par un bug de script.\nFaites nous parvenir cette erreur à undertalefrance@gmail.com\nSi vous êtes sûr que xdelta3 est installé sur votre système, tapez Y puis entrée.\nSinon, quittez l'installeur et tentez une installation manuelle.\nRendez vous sur www.undertale-fr.com pour plus d'informations.\n${normal}"
		read passcheck
		if [ "$passcheck" = "y" ] || [ "$passcheck" = "Y" ]; then
			printf "OK.\n"
			do_it_noinstall
		else
			exit 0
		fi
	fi
}


#Fonctions d'installation du patch xdelta
function do_it_install () {
	printf "Installation de xdelta3...\n"
	if [ "$apt" = "1" ]; then
		sudo apt-get update
		sudo apt-get install xdelta3
	elif [ "$pac" = "1" ]; then
		sudo pacman -S xdelta3
	fi
	printf "Terminé !"
	printf  "Installation du patch...\n"
	xdelta3 -dfs game.unx patchlinux.xdelta patched.unx
	rm game.unx
	mv patched.unx game.unx
}
function do_it_noinstall () {
	printf  "Installation du patch...\n"
	xdelta3 -dfs game.unx patchlinux.xdelta patched.unx
	rm game.unx
	mv patched.unx game.unx
}


#ASCII Art :)
function flowey () {
	printf "          @@@@@@@@  @@@@@@@        \n"
	printf "         @  @@    @@     @ @@      \n"
	printf "        @@   @@@@@@@@@@@@   @@     \n"
	printf "       @@   @@@@@@@@@@@@@    @     \n"
	printf "     @@@@@@@@            @@@@@@@@  \n"
	printf "    @    @@@             @@@@   @@ \n"
	printf "  @@@     @@    @@  @@    @@     @@\n"
	printf "  @@      @     @@  @@     @      @\n"
	printf " @   @@@@@@     @@  @@     @@@@@   @\n"
	printf " @        @     @@  @@     @       @\n"
	printf "  @@@     @   @        @   @     @@\n"
	printf "     @    @@   @@@@@@@@   @    @@  \n"
	printf "     @@@@@@@    @@@@@@   @@@@@@@   \n"
	printf "      @@@@ @@            @@@@@@    \n"
	printf "      @@   @@@@       @@@@@   @    \n"
	printf "     @@   @ @@@@@@@@@@@@@     @@   \n"
	printf "     @@        @@@@@@@@    @  @@   \n"
	printf "     @@         @@@@@@        @@   \n"
	printf "      @@@    @@@@@ @@@@@@    @@    \n"
	printf "       @@@@@@@@@@@@   @@@@@@@@     \n"
	printf "         @@@@            @@@@     \n\n"
}


############ Vérification de l'existence d'xdelta3 et des packet managers ############
if [ -x "$(command -v xdelta3)" ]; then
	printf "${yellow}xdelta3 est déjà installé.\n${normal}"
	xdelta="1"
else
	printf "${yellow}xdelta3 n'est pas installé. Il sera installé automatiquement lorsque vous installerez le patch.\n${normal}"
	xdelta="0"
fi
if [ -x "$(command -v apt-get)" ]; then
	printf "${yellow}Vous utilisez le gestionnaire de paquets APT.\n${normal}"
	apt="1"
else
	printf "${yellow}APT n'est pas disponible.\n${normal}"
	apt="0"
fi
if [ -x "$(command -v pacman)" ]; then
	if [ "$apt" = "0" ]; then
		printf "${yellow}Vous utilisez le gestionnaire de paquets pacman.\n${normal}"
		pac="1"
	else
		printf "${yellow}Les gestionnaires pacman et APT sont tous les deux installés.\napt sera utilisé.${normal}"
		pac="0"
	fi
else
	printf "${yellow}pacman n'est pas disponible.\n${normal}"
	pac="0"
fi
if [[ "$apt" = "0" && "$pac" = "0" ]]; then
	clear
	printf "${red}Erreur ! Aucun des gestionnaires de paquets compatibles avec cet installeur n'a été trouvé !\nVeuillez installer ce patch manuellement avec xdelta3.\nRendez vous sur www.undertale-fr.com pour plus d'informations.\nSi vous êtes certain que vous avez apt ou pacman d'installé,\ncontactez-nous sur undertalefrance@gmail.com pour nous faire parvenir ce bug.\nAppuyez sur entrée pour quitter.\n${normal}"
	read
	exit 0
elif [[ "$apt" = "1" && "$pac" = "1" ]]; then
	clear
	printf "${red}Erreur interne : Les variables apt et pac ont des valeurs invalides !\nVeuillez nous faire parvenir cette erreur à l'adresse undertalefrance@gmail.com\nPour plus d'informations, rendez vous sur www.undertale-fr.com\nArrêt du script.${normal}"
fi
################################################################


#Choix installation
if [[ -e "$datafile" ]]; then
	printf "Fichiers trouvés !\n\n"
	printf "Alors, vous voulez faire quoi ?\nAppuyez la touche correspondante et appuyez sur entrée pour effectuer l'opération assignée :\n\n"
	printf "1) Vous installez le patch pour la première fois : installation du patch\n"
	printf "2) Vous avez déjà installé le patch sur cet ordinateur auparavant : mise à jour du patch\n"
	printf "3) Revenir à la version originale : Désinstallation du patch\n"
	printf "4) Quitter l'installation : annulation du patch\n"
	read menu
	if [ "$menu" = "1" ]; then
		clear
		printf "Backup du fichier original...\n"
		cp game.unx game.unx.backup
		askplatform
		flowey
		printf  "${green}Installation terminée ! Bon jeu !\n${normal}"
		exit 0

		#Choix MAJ
	elif [ "$menu" = "2" ]; then
		clear
		printf  "Vérification de l'existence d'un backup...\n"
		if [ -e "$backupfile" ]; then
			printf "Suppression du fichier patché...\n"
			rm game.unx
			askplatform
			flowey
			printf "${green}Mise à jour terminée ! Bon jeu !\n${normal}"
			exit 0
		else
			printf "${red}Le fichier backup est inexistant ! Mise à jour impossible.\nAppuyez sur entrée pour revenir au menu.${normal}"
			read
			bash install.sh
		fi

		#Choix suppression
	elif [ "$menu" = "3" ]; then
		clear
		printf "Vérification de l'existence d'un backup...\n"
		if [ -e "$backupfile" ]; then
			printf  "Désinstalation du patch...\n"
			rm game.unx
			mv game.unx.backup game.unx
			printf "${green}Désinstallation terminée ! Au revoir !\n${normal}"
		else
			printf "${red}Le fichier backup est inexistant ! Désinstallation impossible.\nAppuyez sur entrée pour revenir au menu.${normal}"
			read
			bash install.sh
		fi

		#Choix quitter
	elif [ "$menu" = "4" ]; then
		clear
		exit 0
	else
		clear
		printf "${red}Entrée invalide. Appuyez sur entrée pour revenir au menu.\n${normal}"
		read
		bash install.sh
	fi

	#Filecheck fail
else
	printf "${red}Erreur ! Le fichier game.unx n'a pas été trouvé, ou le patch est inexistant !\nVérifiez l'endroit où vous avez placé les fichiers puis relancez le script.\nArrêt du script.\n${normal}"
	exit 0
fi
